package com.bet4life.thymeleafapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
